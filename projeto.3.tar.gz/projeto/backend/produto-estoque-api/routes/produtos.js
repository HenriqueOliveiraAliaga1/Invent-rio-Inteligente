const express = require('express');
const router = express.Router();
const Produto = require('../models/Produto');

// Listar produtos
router.get('/', async (req, res) => {
    try {
        const produtos = await Produto.find();
        // map para adicionar campo id (compatibilidade com frontend)
        const mapped = produtos.map(p => ({
            ...p.toObject(),
            id: p._id,
        }));
        res.json(mapped);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao listar produtos' });
    }
});

// Buscar por id
router.get('/:id', async (req, res) => {
    try {
        const p = await Produto.findById(req.params.id);
        if (!p) return res.status(404).json({ error: 'Produto não encontrado' });
        const mapped = { ...p.toObject(), id: p._id };
        res.json(mapped);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao buscar produto' });
    }
});

// Criar produto
router.post('/', async (req, res) => {
    try {
        const { nome, descricao, preco, categoria, quantidade } = req.body;
        const produto = new Produto({ nome, descricao, preco, categoria, quantidade: quantidade || 0 });
        await produto.save();
        res.status(201).json({ ...produto.toObject(), id: produto._id });
    } catch (err) {
        console.error(err);
        res.status(400).json({ error: 'Erro ao criar produto' });
    }
});

// Atualizar produto
router.put('/:id', async (req, res) => {
    try {
        const updated = await Produto.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updated) return res.status(404).json({ error: 'Produto não encontrado' });
        res.json({ ...updated.toObject(), id: updated._id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao atualizar produto' });
    }
});

// Atualizar estoque específico (entrada/saida ou setar quantidade)
router.put('/:id/estoque', async (req, res) => {
    try {
        const { quantidade, operacao } = req.body;
        const produto = await Produto.findById(req.params.id);
        if (!produto) return res.status(404).json({ error: 'Produto não encontrado' });

        if (operacao === 'entrada') {
            produto.quantidade += Number(quantidade || 0);
        } else if (operacao === 'saida') {
            produto.quantidade -= Number(quantidade || 0);
            if (produto.quantidade < 0) produto.quantidade = 0;
        } else if (typeof quantidade !== 'undefined') {
            produto.quantidade = Number(quantidade);
        } else {
            return res.status(400).json({ error: 'Operação inválida' });
        }

        await produto.save();
        res.json({ ...produto.toObject(), id: produto._id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao atualizar estoque' });
    }
});

// Deletar produto
router.delete('/:id', async (req, res) => {
    try {
        const p = await Produto.findByIdAndDelete(req.params.id);
        if (!p) return res.status(404).json({ error: 'Produto não encontrado' });
        res.json({ message: 'Produto removido com sucesso' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao remover produto' });
    }
});

module.exports = router;
