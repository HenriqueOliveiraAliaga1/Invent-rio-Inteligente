const mongoose = require('mongoose');

const ProdutoSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    descricao: { type: String, default: '' },
    preco: { type: Number, default: 0 },
    categoria: { type: String, default: '' },
    quantidade: { type: Number, default: 0 }, // quantidade atual / estoque
}, { timestamps: true });

module.exports = mongoose.model('Produto', ProdutoSchema);
