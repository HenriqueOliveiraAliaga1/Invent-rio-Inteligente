const express = require('express');
const router = express.Router();
const Produto = require('../models/Produto');

router.get('/', async (req, res) => {
    try {
        const produtos = await Produto.find();
        const estoque = produtos.map(p => ({
            produto_id: p._id,
            quantidade_atual: p.quantidade || 0,
            quantidade_minima: 0,
            ultima_atualizacao: p.updatedAt
        }));
        res.json(estoque);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao listar estoque' });
    }
});

module.exports = router;
