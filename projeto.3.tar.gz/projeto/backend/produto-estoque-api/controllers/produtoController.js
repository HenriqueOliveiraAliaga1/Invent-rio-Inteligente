const Produto = require('../models/Produto');

// Criar produto
const criarProduto = async (req, res) => {
  try {
    const { nome, preco, quantidade } = req.body;

    const produto = new Produto({
      nome,
      preco,
      quantidade
    });

    const produtoSalvo = await produto.save();
    res.status(201).json(produtoSalvo);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Listar todos os produtos
const listarProdutos = async (req, res) => {
  try {
    const produtos = await Produto.find();
    res.json(produtos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Buscar produto por ID
const buscarProduto = async (req, res) => {
  try {
    const produto = await Produto.findById(req.params.id);
    
    if (!produto) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    res.json(produto);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Atualizar produto
const atualizarProduto = async (req, res) => {
  try {
    const { nome, preco, quantidade } = req.body;

    const produto = await Produto.findByIdAndUpdate(
      req.params.id,
      { nome, preco, quantidade },
      { new: true, runValidators: true }
    );

    if (!produto) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    res.json(produto);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Excluir produto
const excluirProduto = async (req, res) => {
  try {
    const produto = await Produto.findByIdAndDelete(req.params.id);

    if (!produto) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    res.json({ message: 'Produto excluído com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Atualizar estoque (para integração com vendas)
const atualizarEstoque = async (req, res) => {
  try {
    const { quantidade, operacao } = req.body;

    const produto = await Produto.findById(req.params.id);

    if (!produto) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    await produto.atualizarEstoque(quantidade, operacao);
    res.json(produto);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

module.exports = {
  criarProduto,
  listarProdutos,
  buscarProduto,
  atualizarProduto,
  excluirProduto,
  atualizarEstoque
};
