const BackendConfig = {
    baseURL: '/api',   // para acesso local direto / quando rodando dev
    timeout: 8000,
    headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
};

class BackendAPI {
    constructor(config = BackendConfig) {
        this.config = config;
    }

    async request(endpoint, options = {}) {
        const url = `${this.config.baseURL}${endpoint}`;
        const finalOptions = {
            method: "GET",
            headers: this.config.headers,
            ...options
        };
        try {
            const response = await fetch(url, finalOptions);
            if (!response.ok) throw new Error("Erro HTTP: " + response.status);
            return await response.json();
        } catch (err) {
            console.error("Erro na requisição:", err);
            throw err;
        }
    }

    // produtos
    getProdutos() { return this.request('/produtos'); }
    createProduto(produto) { return this.request('/produtos', { method: "POST", body: JSON.stringify(produto) }); }
    updateProduto(id, produto) { return this.request(`/produtos/${id}`, { method: "PUT", body: JSON.stringify(produto) }); }
    deleteProduto(id) { return this.request(`/produtos/${id}`, { method: "DELETE" }); }

    // estoque
    async getEstoque() {
        // backend tem /estoque (mapeado por nós)
        return this.request('/estoque');
    }
    updateEstoque(produtoId, dados) {
        return this.request(`/produtos/${produtoId}/estoque`, { method: "PUT", body: JSON.stringify(dados) });
    }

    // vendas
    getVendas() { return this.request('/vendas'); }
    createVenda(venda) { return this.request('/vendas', { method: "POST", body: JSON.stringify(venda) }); }
    deleteVenda(id) { return this.request(`/vendas/${id}`, { method: "DELETE" }); }
}

window.BackendAPI = BackendAPI;
