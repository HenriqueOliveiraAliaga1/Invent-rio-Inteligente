const express = require('express');
const cors = require('cors');
const connectDB = require('./config/database');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Conectar Mongo
connectDB();

// Rotas
app.use('/produtos', require('./routes/produtos'));
app.use('/vendas', require('./routes/vendas'));
app.use('/estoque', require('./routes/estoque'));

// Root (diagnóstico)
app.get('/', (req, res) => {
    res.json({ message: 'API de Produtos rodando' });
});

app.listen(PORT, () => {
    console.log(`API rodando na porta ${PORT}`);
});
