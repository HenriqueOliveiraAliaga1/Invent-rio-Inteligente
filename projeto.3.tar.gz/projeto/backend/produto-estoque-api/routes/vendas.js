const express = require('express');
const router = express.Router();
const Venda = require('../models/Venda');

router.get('/', async (req, res) => {
    try {
        const vendas = await Venda.find().populate('produto_id');
        res.json(vendas);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao listar vendas' });
    }
});

router.post('/', async (req, res) => {
    try {
        const venda = new Venda(req.body);
        await venda.save();
        res.status(201).json(venda);
    } catch (err) {
        console.error(err);
        res.status(400).json({ error: 'Erro ao criar venda' });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const v = await Venda.findByIdAndDelete(req.params.id);
        if (!v) return res.status(404).json({ error: 'Venda não encontrada' });
        res.json({ message: 'Venda removida' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao remover venda' });
    }
});

module.exports = router;
