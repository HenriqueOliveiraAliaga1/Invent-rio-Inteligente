#!/bin/bash

echo "Construindo as imagens..."
docker-compose build

echo "Subindo containers..."
docker-compose up -d

echo "Containers rodando!"
docker ps
