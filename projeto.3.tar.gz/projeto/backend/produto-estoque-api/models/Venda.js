const mongoose = require('mongoose');

const VendaSchema = new mongoose.Schema({
    produto_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Produto', required: true },
    quantidade: { type: Number, required: true },
    preco_unitario: { type: Number, required: true },
    total: { type: Number, required: true },
    cliente: { type: String, default: '' },
    data_venda: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model('Venda', VendaSchema);
